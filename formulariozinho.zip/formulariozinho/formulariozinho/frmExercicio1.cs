﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace formulariozinho
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void btnSoma_Click(object sender, EventArgs e)
        {
            float num1 = float.Parse(txtNum1.Text);
            float num2 = float.Parse(txtNum2.Text);
            float num3 = float.Parse(txtNum3.Text);
            float soma;
            //calcular a soma
            soma = num1 + num2 + num3;

            // mostrar resultado 
            MessageBox.Show("Resultado:" + soma);

        
        }

        private void btnMedia_Click(object sender, EventArgs e)
        {
            float num1 = float.Parse(txtNum1.Text);
            float num2 = float.Parse(txtNum2.Text);
            float num3 = float.Parse(txtNum3.Text);
            float Media;
            //calcule a media
            Media = (num1 + num2 + num3) / 3;
            
            //mostre o resultado 
            MessageBox .Show ("Resultado" + Media);
        }

        private void btnPorcetagem_Click(object sender, EventArgs e)
        {
            float num1 = float.Parse(txtNum1.Text);
            float num2 = float.Parse(txtNum2.Text);
            float num3 = float.Parse(txtNum3.Text);
            float Porcetagem;
            
            //calculo
            Porcetagem = num1/(num1 + num2 num3) * 100;
            
            //mostre o calculo 
            MessageBox.Show("ressultado" + Porcetagem "%"); 
        }
    }
}
