﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppCalculadora
{
    public partial class FormCalculadora : Form
    {
        public FormCalculadora()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            float Numero1 = float.Parse(txtN1.Text);
            float numero2 = float.Parse(txtN2.Text);
            float resultado;

            //subitração
            resultado = Numero1 - numero2;
            MessageBox.Show("resultado:" + resultado);
        }

        private void lblN2_Click(object sender, EventArgs e)
        {

        }

        private void FormCalculadora_Load(object sender, EventArgs e)
        {

        }

        private void BtnMultiplicação_Click(object sender, EventArgs e)
        {
            float Numero1 = float.Parse(txtN1.Text);
            float Numero2 = float.Parse(txtN2.Text);
            float resultado;

            //multiplicação
            resultado = Numero1 * Numero2;
            MessageBox.Show("resultado:" + resultado);
        }

        private void txtN1_TextChanged(object sender, EventArgs e)
        {

        }

        private void BtnSoma_Click(object sender, EventArgs e)
        {
            float Numero1 = float.Parse(txtN1.Text);
            float numero2 = float.Parse(txtN2.Text);
            float resultado;


            //soma;
            resultado = Numero1 + numero2;
            MessageBox.Show("resultado:" + resultado);
        }

        private void BtnDivisão_Click(object sender, EventArgs e)
        {
            float Numero1 = float.Parse(txtN1.Text);
            float numero2 = float.Parse(txtN2.Text);
            float resultado;

            //divisão
            resultado=Numero1 / numero2;
            MessageBox.Show("resultado:" + resultado);
        }
    }
}
