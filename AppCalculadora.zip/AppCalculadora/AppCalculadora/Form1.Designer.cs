﻿namespace AppCalculadora
{
    partial class FormCalculadora
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblN1 = new System.Windows.Forms.Label();
            this.lblN2 = new System.Windows.Forms.Label();
            this.txtN1 = new System.Windows.Forms.TextBox();
            this.txtN2 = new System.Windows.Forms.TextBox();
            this.BtnSoma = new System.Windows.Forms.Button();
            this.btnSubtração = new System.Windows.Forms.Button();
            this.BtnDivisão = new System.Windows.Forms.Button();
            this.BtnMultiplicação = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblN1
            // 
            this.lblN1.AutoSize = true;
            this.lblN1.BackColor = System.Drawing.Color.Transparent;
            this.lblN1.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.lblN1.Location = new System.Drawing.Point(107, 66);
            this.lblN1.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblN1.Name = "lblN1";
            this.lblN1.Size = new System.Drawing.Size(87, 25);
            this.lblN1.TabIndex = 0;
            this.lblN1.Text = "número 1";
            this.lblN1.Click += new System.EventHandler(this.label1_Click);
            // 
            // lblN2
            // 
            this.lblN2.AutoSize = true;
            this.lblN2.BackColor = System.Drawing.Color.Transparent;
            this.lblN2.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.lblN2.Location = new System.Drawing.Point(392, 66);
            this.lblN2.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblN2.Name = "lblN2";
            this.lblN2.Size = new System.Drawing.Size(87, 25);
            this.lblN2.TabIndex = 1;
            this.lblN2.Text = "número 2";
            this.lblN2.Click += new System.EventHandler(this.lblN2_Click);
            // 
            // txtN1
            // 
            this.txtN1.Location = new System.Drawing.Point(69, 116);
            this.txtN1.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.txtN1.Name = "txtN1";
            this.txtN1.Size = new System.Drawing.Size(164, 32);
            this.txtN1.TabIndex = 2;
            this.txtN1.TextChanged += new System.EventHandler(this.txtN1_TextChanged);
            // 
            // txtN2
            // 
            this.txtN2.Location = new System.Drawing.Point(374, 116);
            this.txtN2.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.txtN2.Name = "txtN2";
            this.txtN2.Size = new System.Drawing.Size(164, 32);
            this.txtN2.TabIndex = 3;
            // 
            // BtnSoma
            // 
            this.BtnSoma.Location = new System.Drawing.Point(151, 187);
            this.BtnSoma.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.BtnSoma.Name = "BtnSoma";
            this.BtnSoma.Size = new System.Drawing.Size(125, 44);
            this.BtnSoma.TabIndex = 4;
            this.BtnSoma.Text = "+";
            this.BtnSoma.UseVisualStyleBackColor = true;
            this.BtnSoma.Click += new System.EventHandler(this.BtnSoma_Click);
            // 
            // btnSubtração
            // 
            this.btnSubtração.Location = new System.Drawing.Point(354, 187);
            this.btnSubtração.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.btnSubtração.Name = "btnSubtração";
            this.btnSubtração.Size = new System.Drawing.Size(125, 44);
            this.btnSubtração.TabIndex = 5;
            this.btnSubtração.Text = "-";
            this.btnSubtração.UseVisualStyleBackColor = true;
            this.btnSubtração.Click += new System.EventHandler(this.button2_Click);
            // 
            // BtnDivisão
            // 
            this.BtnDivisão.Location = new System.Drawing.Point(354, 265);
            this.BtnDivisão.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.BtnDivisão.Name = "BtnDivisão";
            this.BtnDivisão.Size = new System.Drawing.Size(125, 44);
            this.BtnDivisão.TabIndex = 6;
            this.BtnDivisão.Text = "/";
            this.BtnDivisão.UseVisualStyleBackColor = true;
            this.BtnDivisão.Click += new System.EventHandler(this.BtnDivisão_Click);
            // 
            // BtnMultiplicação
            // 
            this.BtnMultiplicação.Location = new System.Drawing.Point(151, 265);
            this.BtnMultiplicação.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.BtnMultiplicação.Name = "BtnMultiplicação";
            this.BtnMultiplicação.Size = new System.Drawing.Size(125, 44);
            this.BtnMultiplicação.TabIndex = 7;
            this.BtnMultiplicação.Text = "x";
            this.BtnMultiplicação.UseVisualStyleBackColor = true;
            this.BtnMultiplicação.Click += new System.EventHandler(this.BtnMultiplicação_Click);
            // 
            // FormCalculadora
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MidnightBlue;
            this.ClientSize = new System.Drawing.Size(596, 375);
            this.Controls.Add(this.BtnMultiplicação);
            this.Controls.Add(this.BtnDivisão);
            this.Controls.Add(this.btnSubtração);
            this.Controls.Add(this.BtnSoma);
            this.Controls.Add(this.txtN2);
            this.Controls.Add(this.txtN1);
            this.Controls.Add(this.lblN2);
            this.Controls.Add(this.lblN1);
            this.Font = new System.Drawing.Font("Arial Narrow", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.Name = "FormCalculadora";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.FormCalculadora_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblN1;
        private System.Windows.Forms.Label lblN2;
        private System.Windows.Forms.TextBox txtN1;
        private System.Windows.Forms.TextBox txtN2;
        private System.Windows.Forms.Button BtnSoma;
        private System.Windows.Forms.Button btnSubtração;
        private System.Windows.Forms.Button BtnDivisão;
        private System.Windows.Forms.Button BtnMultiplicação;
    }
}

