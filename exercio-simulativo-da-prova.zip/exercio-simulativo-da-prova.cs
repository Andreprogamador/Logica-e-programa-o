﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppSimProva_Andre_2C
{
    public partial class FrmExercicio_1 : Form
    {
        public FrmExercicio_1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void FrmExercicio_1_Load(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void btnCalcular1_Click(object sender, EventArgs e)
        {
            //pegar o preço
            float preco1 = float.Parse(txtPreco1);
            float preco2 = float.Parse(txtPreco2);
            float preco3 = float.Parse(txtPreco3);

            //
        }
    }
}
